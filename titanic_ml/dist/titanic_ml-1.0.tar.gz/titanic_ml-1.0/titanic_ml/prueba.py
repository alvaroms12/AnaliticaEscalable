import os
print("ruta: ", os.getcwd())

# titanic_ml\titanic_ml\prueba.py
# H:\Mi unidad\Master\9. Analítica Escalable\Bloque 2\PEC2\Proyecto\titanic_ml\titanic_ml\prueba.py